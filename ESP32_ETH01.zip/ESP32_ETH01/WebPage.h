#pragma once
#include <Arduino.h>
#include "LogoF4BIT.h"

// Interface Web - HTML, CSS et JavaScript
// Les couleurs sont definies dans :root.
// Le logo JPEG est stocke dans LogoF4BIT.h.
// Aucun fichier externe n'est necessaire au navigateur.

const char html[] PROGMEM = R"ANTENNA_HTML(
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Antenna Control Center</title>

<style>
/* 1. Palette de couleurs */
:root {
  --fond-page: #000063;
  --texte: #fffbff;
  --bordure-inactive: #f73d5a;
  --fond-inactif: #290019;
  --bordure-active: #21c65a;
  --fond-actif: #004121;
  --bordure-bleue: #00a2ff;
  --bordure-interieure: #0096ff;
}

/* 2. Mise en page et composants */
* {
  box-sizing: border-box;
}

body {
  margin: 0;
  background: var(--fond-page);
  color: var(--texte);
  font-family: Arial,sans-serif;
}

.container {
  max-width: 1000px;
  margin: auto;
  padding: 12px;
}

header img {
  display: block;
  width: 100%;
  height: auto;
}

/* Grille des neuf relais */
.grid {
  display: grid;
  grid-template-columns: repeat(3,minmax(0,1fr));
  gap: 12px;
  margin: 12px 1.5%;
}

/* Bouton inactif par defaut */
.card {
  min-height: clamp(64px,12vw,120px);
  border: 2px solid var(--bordure-inactive);
  background: var(--fond-inactif);
  border-radius: 18px;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  color: var(--texte);
  user-select: none;
}

/* Bouton actif */
.card.active {
  border-color: var(--bordure-active);
  background: var(--fond-actif);
}

.card:focus-visible {
  outline: 2px solid var(--bordure-bleue);
  outline-offset: 3px;
}

.card:hover {
  filter: brightness(1.15);
}

.name {
  padding: 10px;
  text-align: center;
  font-size: clamp(14px,2.3vw,24px);
  font-weight: 600;
  overflow-wrap: anywhere;
}

/* Pied de page : IP et licence */
footer {
  margin: 12px 1.5%;
  border: 2px solid var(--bordure-bleue);
  box-shadow: inset 0 0 0 1px var(--bordure-interieure);
  border-radius: 12px;
  display: grid;
  grid-template-columns: 46% 54%;
  align-items: center;
  padding: 10px 0;
  text-align: center;
  font-size: clamp(11px,1.8vw,19px);
}

footer span {
  padding: 3px 6px;
}

footer span+span {
  border-left: 1px solid var(--texte);
}

/* Adaptation aux petits ecrans */
@media(max-width:560px) {
  .container {
    padding: 6px;
  }
  .grid {
    gap: 7px;
  }
  .card {
    border-radius: 13px;
  }
  .name {
    padding: 5px;
  }
  footer {
    margin-top: 8px;
  }
}
</style>
</head>

<body>
<div class="container">

<!-- Bandeau graphique F4BIT -->
<header>
  <img alt="F4BIT - Antenna Control Center" src="data:image/jpeg;base64,)ANTENNA_HTML"
  F4BIT_LOGO_BASE64
  R"ANTENNA_HTML(">
</header>

<main id="grid" class="grid"></main>

<!-- Pied de page -->
<footer>
  <span id="ip">IP : --</span>
  <span>2026 @ Copyleft GNU GPL v3</span>
</footer>

</div>

<script>
// Affichage des relais et de leurs etats
function render(data) {
  const grid=document.getElementById("grid");
  grid.innerHTML="";

  const names=Object.keys(data);

  names.forEach(function(name,index){
    const active=!!data[name];

    const card=document.createElement("div");
    card.className="card"+(active?" active":"");
    card.setAttribute("role","button");
    card.setAttribute("tabindex","0");

    const title=document.createElement("div");
    title.className="name";
    title.textContent=name;

    card.appendChild(title);

    card.addEventListener("click",function(){
      toggle(index,active);
    });

    card.addEventListener("keydown",function(event){
      if(event.key==="Enter"||event.key===" "){
        event.preventDefault();
        toggle(index,active);
      }
    });

    grid.appendChild(card);
  });
}

// Envoi de la commande au serveur ESP32
function toggle(idx, currentState) {
  const newState=currentState?0:1;

  fetch("/api/set?relay="+idx+"&on="+newState)
    .then(function(response){
      if(!response.ok){
        throw new Error("HTTP "+response.status);
      }
      return response.text();
    })
    .then(function(){
      refresh();
    })
    .catch(function(error){
      console.error(error);
      refresh();
    });
}

// Lecture des etats depuis le serveur
function refresh() {
  fetch("/api/state",{cache:"no-store"})
    .then(function(response){
      if(!response.ok){
        throw new Error("HTTP "+response.status);
      }
      return response.json();
    })
    .then(function(data){
      render(data);
    })
    .catch(function(error){
      console.error(error);
    });
}

// Adresse du serveur et actualisation toutes les 5 secondes
document.getElementById("ip").textContent = "IP : "+location.hostname;
refresh();
setInterval(refresh,5000);
</script>

</body>
</html>
)ANTENNA_HTML";

#undef F4BIT_LOGO_BASE64
